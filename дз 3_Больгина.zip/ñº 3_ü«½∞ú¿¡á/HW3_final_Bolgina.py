import re
import numpy as np
from matplotlib import pyplot as plt
from sklearn import grid_search, svm

with open('anna.txt', encoding='utf-8') as f:
    anna = f.read()

with open('sonets.txt', encoding='utf-8') as f:
    sonets = f.read()
symbols = ['ё','й','ц','у','к','е','н','г','ш','щ','з','х','ъ','ф','ы','в','а','п','р','о','л','д','ж','э','я','ч','с','м','и','т','ь','б','ю']
vovels = ['ё','у','е','ы','а','о','э','я','и','ю']
anna_sentences = re.split(r'(?:[.]\s*){3}|[.?!]', anna)
anna_data = []
sonet_sentences = re.split(r'(?:[.]\s*){3}|[.?!]', sonets)
sonet_data = []

for sentence in anna_sentences:# обработка файла Анны Карениной
    if sentence != '':
        sentence_vectors = []
        sentence = sentence.lower()
        letters = []
        for i in sentence:
            if i in symbols:
                letters.append(i)
        sentence_vectors.append(len(letters))
        uniqletters = []
        vovletters = []
        for i in letters:
            if i not in uniqletters:
                uniqletters.append(i)
            if i in vovels:
                vovletters.append(i)
        sentence_vectors.append(len(uniqletters))
        sentence_vectors.append(len(vovletters))
        lenwords = []
        lenvovsent = []
        for word in sentence.split():
            vovword = []
            word = word.strip(',"')
            if len(word) > 0:
                lenwords.append(len(word))

            for i in word:
                if i in vovels:
                    vovword.append(i)
            lenvovsent.append(len(vovword))
        if np.median(lenwords) > 0:
            sentence_vectors.append(np.median(lenwords))
        if np.median(lenvovsent) > 0:
            sentence_vectors.append(np.median(lenvovsent))
        sentence_vectors.append(1)# помечаем все предложения текста про сонеты - цифрой 1
        #sentence_vectors = [(len(letters), len(uniqletters),len(vovletters), np.median(lenwords), np.median(lenvovsent))]
    if len(sentence_vectors) == 6:
        anna_data.append(sentence_vectors)

for sentence in sonet_sentences:# обработка файла сонетов
    if sentence != '':
        sentence_vectors = []
        sentence = sentence.lower()
        letters = []
        for i in sentence:
            if i in symbols:
                letters.append(i)
        sentence_vectors.append(len(letters))
        uniqletters = []
        vovletters = []
        for i in letters:
            if i not in uniqletters:
                uniqletters.append(i)
            if i in vovels:
                vovletters.append(i)
        sentence_vectors.append(len(uniqletters))
        sentence_vectors.append(len(vovletters))
        lenwords = []
        lenvovsent = []
        for word in sentence.split():
            vovword = []
            word = word.strip(',"')
            if len(word) > 0:
                lenwords.append(len(word))

            for i in word:
                if i in vovels:
                    vovword.append(i)
            lenvovsent.append(len(vovword))
        if np.median(lenwords) > 0:
            sentence_vectors.append(np.median(lenwords))
        if np.median(lenvovsent) > 0:
            sentence_vectors.append(np.median(lenvovsent))
        sentence_vectors.append(2)# помечаем все предложения текста про сонеты - цифрой 2
    if len(sentence_vectors) == 6:
        sonet_data.append(sentence_vectors)
anna = []
for i in anna_data:
    l = tuple(i)
    anna.append(l)
#print(anna[:10])

sonet = []
for i in sonet_data:
    l = tuple(i)
    sonet.append(l)
#print(sonet[:10])

anna = np.array(anna)
sonet = np.array(sonet)
data = np.vstack((anna, sonet))#перемешиваем оба текста
from sklearn.model_selection import train_test_split
test, train = train_test_split(data, random_state=3, test_size=0.3)
#print(data)
#print(sonet)
#print(anna)
#plt.figure()
#plt.plot(anna[:,3], anna[:,4], 'og',
         #sonet[:,3], sonet[:,4], 'sb')
#plt.show()#Я перебрала все варианты(смотреть графики в отдельной папке) На мой взгляд, тексты лучше всего различаются по 0 и 2, 2 и 3, где 0 - длина предложения в буквах, 2 - число различных букв в предложении, 3 - число гласных в предложении

parameters = {'C': (.1, .05, 0.04, 0.03, 0.2, 0.01)}
gs = grid_search.GridSearchCV(svm.LinearSVC(), parameters)
gs.fit(data[:, :4], data[:, 5])
print('Best result is ',gs.best_score_)
print('Best C is', gs.best_estimator_.C)
clf = svm.LinearSVC(C=gs.best_estimator_.C)
clf.fit(train[:, :4], train[:, 5])

wrong = 0
answ = []
for obj in test[:,:]:

    label = clf.predict(obj[:4]).item(0)
    #print(label != obj[5])
    #print(label)
    #print(obj[5])
    answ.append((label,obj[5]))
    if float(label) != float(obj[5]):
        print('Пример ошибки машины: class = ', obj[5], ', label = ', label, ', экземпляр ', obj[:4])
        wrong += 1
    if wrong > 3:
        break

print(answ)